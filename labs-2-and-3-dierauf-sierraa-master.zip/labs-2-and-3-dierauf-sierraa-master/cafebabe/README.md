About
-----

Cafebabe is a tiny Scala library to generate JVM class files. It was originally
developed for the Compiler Construction course taught at EPFL. See
http://lara.epfl.ch/w/Teaching for more info.

The wiki on GitHub contains some documentation.
