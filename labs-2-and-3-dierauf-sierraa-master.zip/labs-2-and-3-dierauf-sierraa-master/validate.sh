#!/bin/bash

echo "Validating $@"
echo "run --ppt $@" | sbt

