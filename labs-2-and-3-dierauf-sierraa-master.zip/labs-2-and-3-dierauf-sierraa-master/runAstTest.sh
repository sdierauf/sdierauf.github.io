#!/bin/bash

echo "Starting tests for:" lab3
echo "run --testAst src/test/lab3/valid" | sbt

